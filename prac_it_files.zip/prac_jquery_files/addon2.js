var sol = (document).getElementById("ao2").innerHTML;
let e = 12;
let flag = 0;
let t=1;
while(flag == 0 & t<=3){
    a = prompt("Solve the proble: 4+8");
    if(a==e){
        document.getElementById("output").innerHTML += `<div>Accepted ${a}</div>`;
        break;
    }
    else if(t!=3){
        document.getElementById("output").innerHTML += `<div>Rejected ${a}.Retry.</div>`
    }
    if(t==3){
        document.getElementById("output").innerHTML += `<div>Rejected ${a}.</div>`
    }
    t++;
}