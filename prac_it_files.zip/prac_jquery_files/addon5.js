var n = prompt("Enter Number");
console.log(n);
var s=``;
function fib(num){
    let a = 0;
    let b = 1;
    s+=`<h1>${a}</h1>`
    if(num!=0)
    {
        s+=`<h1>${b}</h1>`
    }
    c=1;
    while(c<n)
    {
        c = a+b;
        a=b;
        b=c;
        s+=`<h1>${b}</h1>`;
    }
}
console.log(fib(n));
document.getElementById('fib').innerHTML=s;