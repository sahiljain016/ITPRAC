var num = prompt("Enter a number");
console.log(num);
function fact(n) {
    var f = 1;
    while (n > 1) {
        f = f * n;
        n--;
    }
    return f;
}
console.log(fact(num));
(document).getElementById("fact").innerHTML = `Factorial : ${fact(num)}`