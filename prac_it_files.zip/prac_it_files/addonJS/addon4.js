function fill(){
    a=[];
    let l=1;
    while(l<6)
    {
        a.push(document.getElementById(`num${l}`).value);
        l++;
    }
    console.log(a)
}
function sorte(){
    fill();
    document.getElementById("sorted").innerHTML=`Sorted Array: ${a.sort()}`;
}
function reversee(){
    fill();
    document.getElementById("reversed").innerHTML=`Reversed Array: ${a.reverse()}`;

}