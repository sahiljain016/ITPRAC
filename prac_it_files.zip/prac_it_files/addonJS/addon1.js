$(document).ready(function(){
    $('#submit').click(function(){
        var d = new Date(); // for now
        hours=d.getHours(); // => 9
        minutes=d.getMinutes(); // =>  30
        if(hours>=6 & hours<12)
        {
            var msg="Good Morning";
        }
        else if (hours>=12 & hours<16) {

            var msg="Good Afternoon";
            
        } else if(hours>=16 & hours<20){
            var msg="Good Evening";
        }
        else{
            var msg="Good Night";
        }
        prompt(msg,$('#input').val())

    })

})