function getfocus(){
    document.getElementById("input").focus();
}
function getblur(){
    document.getElementById("input").blur();
}
function selecttext(){
    document.getElementById("input").select();
}
const btn = document.querySelector('#btn');        
const radioButtons = document.querySelectorAll('input[name="actions"]');
btn.addEventListener("click", () => {
    let v=document.getElementById('value').value
    for (const radioButton of radioButtons) {
        if (radioButton.checked) {
            if(radioButton.value=="square")
            {
                document.getElementById("result").value=v*v;
            }
            else if(radioButton.value=="double")
            {
                document.getElementById("result").value=2*v;

            }
        }
    }
})