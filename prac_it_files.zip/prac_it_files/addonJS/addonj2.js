var a=[4,5,7,8,2,9,7];
s=`<div>${a.toString()}</div>`;
s+=`<div>${a.join(' ')}</div>`;
a.push(8);
a.pop(9);
a=a.shift();
s+=`<div>${a}</div>`;
// • toString()
// • join()
// • push()
// • pop()
// • shift()
// • unshift()
// • splice()
// • concat()
// • slice()
document.getElementById('output').innerHTML=s;

// • indexOf()
// • lastIndexOf()
// • search()
// • slice()
// • substring()
// • substr()
// • replace()
// • match()
// • toUpperCase()
// • toLowerCase()
// • concat()
// • charAt()
// • charCodeAt()
// • split()

// • toString()
// • toExponential()
// • toFixed()
// • toPrecision()
// • valueOf()
// • Number()
// • parseInt()
// • parseFloat()

// • getDate()
// • getDay()
// • getFullYear()
// • getHours()
// • getMilliseconds()
// • getMinutes()
// • getMonth()
// • getSeconds()
// • getTime()
// • setDate()
// • setFullYear()
// • setHours()
// • setMilliseconds()
// • setMinutes()
// • setMonth()
// • setSeconds()
// • setTime()
