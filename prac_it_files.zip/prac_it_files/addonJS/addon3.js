var num=prompt("Enter a number");
console.log(num)
function fact(n) {
    var prod=1
    while(n>1){
        prod*=n;
        n--;
    }
    return prod;
}
console.log(fact(num));
(document).getElementById("fact").innerHTML=`Factorial of ${num}: ${fact(num)}`