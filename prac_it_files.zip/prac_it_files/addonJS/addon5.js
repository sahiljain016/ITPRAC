var num=prompt("Enter a number");
console.log(num)
var s=``;
function fib(n) {
    let a=0;
    let b=1;
    s+=`<h1>${a}</h1>`
    if(num!=0)
    {
        s+=`<h1>${b}</h1>`
    }
    c=1;
    while(c<n)
    {
        c=a+b;
        a=b;
        b=c;
        s+=`<h1>${b}</h1>`;
    }
}
console.log(fib(num));
document.getElementById('fib').innerHTML=s;


