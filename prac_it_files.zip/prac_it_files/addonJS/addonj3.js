var s=[];
function addOrder(x)
{
    s.push(x.innerHTML);
    document.getElementById("textbox").value+=x.innerHTML+'\r\n';
}
function addMiss(){
    var e = document.getElementById("Miscellaneous");
    var text = e.options[e.selectedIndex].text;
    document.getElementById("textbox").value+=text+'\r\n';

}